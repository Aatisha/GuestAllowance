﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using GuestAllowance.Models;
using GuestAllowance.Common;

namespace GuestAllowance.Controllers
{
    public class HomeController : Controller
    {
        MiniProjectEntity entities = new MiniProjectEntity();
        public ActionResult Login()
        {
            return View();
        }
        [HttpPost]
        //[ValidateAntiForgeryToken]
        public ActionResult Login(User user)
        {
            var _username = entities.Users.Where(s => s.Name == user.Name);
            if (_username.Any())
            {
                if (_username.Where(s => s.Password == user.Password).Any())
                {
                    if (_username.Where(s => s.Role.Equals("Resident")).Any())
                    {
                        Session["UserID"] = user.Id.ToString();
                        Session["UserName"] = user.Name.ToString();
                        return RedirectToAction("CreateInvite");
                    }
                    else
                    {
                        return RedirectToAction("SecurityView");
                    }
                }
                else
                {
                    return View("InvalidLogin");
                }
            }
            else
            {
                return View("InvalidLogin");

            }
        }       
        public ActionResult InvalidLogin()
        {
            return View();
        }

        public ActionResult SecurityView()
        {
            return View();
        }
        public ActionResult CreateInvite()
        {
            return View();
        }
        [HttpPost]
        public ActionResult CreateInvite(PassGenerated passGenerated)
        {
           passGenerated.Otp= CodeGenerator.GenerateCode();
           passGenerated.Status = "Pending";
           passGenerated.AddrId = 2;
           // Session["UserID"] = user.Id.ToString();
            entities.PassGenerateds.Add(passGenerated);
           entities.SaveChanges();
            return View();
        }
        public ActionResult SignUp()
        {       
            return View();
        }
        [HttpPost]
        public ActionResult SignUp(User user)
        {
            entities.Users.Add(user);
            entities.SaveChanges();
            return View();
        }
    }
}